import 'dart:convert';
import 'dart:html';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class Gejala extends StatelessWidget {
  Gejala({super.key});

  final url = Uri.https('pakar.tempatngoding.my.id', 'gejala');

  Future<List<dynamic>> _fetchDataGejala() async {
    var result = await http.get(url);
    return json.decode(result.body)['data'];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Data Gejala'),
      ),
      body: FutureBuilder<List<dynamic>>(
        future: _fetchDataGejala(),
        builder: (BuildContext context, AsyncSnapshot snapshot) {
          if (snapshot.hasData) {
            return ListView.builder(
                itemCount: snapshot.data!.length,
                itemBuilder: (BuildContext context, int index) {
                  return ListTile(
                    title: Text(snapshot.data![index]['nama']),
                    subtitle: Text(snapshot.data![index]['kode']),
                  );
                });
          } else {
            return const Center(child: CircularProgressIndicator());
          }
        },
      ),
    );
  }
}
