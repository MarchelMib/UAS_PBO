import 'dart:html';

import 'package:flutter/material.dart';
import 'package:menu_app/gejala.dart';

class DrawerWidget extends StatelessWidget {
  const DrawerWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
        child: ListView(
      children: [
        _drawerHeader(),
        _drawerItem('Dashboard', () {
          Navigator.push(context, MaterialPageRoute(builder: (context) {
            return Gejala();
          }));
        }),
        _drawerItem('Gejala', () {
          print('Memilih Gejala');
        }),
        _drawerItem('Penyakit', () {
          print('Memilih Penyakit');
        }),
        _drawerItem('Aturan', () {
          print('Memilih Aturan');
        }),
      ],
    ));
  }

  Widget _drawerHeader() {
    return const UserAccountsDrawerHeader(
      currentAccountPicture:
          Image(image: AssetImage('assets/images/jepege.jpg')),
      accountName: Text('Wadah Ngoding'),
      accountEmail: Text("marchelmib5@gmail.com"),
    );
  }

  Widget _drawerItem(String textItem, GestureTapCallback onTap) {
    return ListTile(
      title: Text(textItem),
      onTap: onTap,
    );
  }
}
